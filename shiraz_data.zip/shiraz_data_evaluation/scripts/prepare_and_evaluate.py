# -*- coding: utf-8 -*-
"""
پاک‌سازی، آماده‌سازی و ارزیابی داده‌های مسیریابی شهری شیراز
ورودی‌ها: shiraz_drive.graphml و shiraz_2d_grid.npy
خروجی‌ها: گزارش کیفیت، جدول داده‌های پاک‌سازی‌شده و ارزیابی مسیرها
"""
from pathlib import Path
import argparse, json, random
import numpy as np
import pandas as pd
import networkx as nx

def to_number(value):
    """تبدیل امن مقدار به عدد؛ مقدار نامعتبر به NaN تبدیل می‌شود."""
    try:
        return float(value)
    except (TypeError, ValueError):
        return np.nan

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--graph", required=True, help="مسیر فایل shiraz_drive.graphml")
    parser.add_argument("--grid", required=True, help="مسیر فایل shiraz_2d_grid.npy")
    parser.add_argument("--out", default="results", help="پوشه ذخیره نتایج")
    parser.add_argument("--pairs", type=int, default=25, help="تعداد جفت مبدأ-مقصد آزمایشی")
    args = parser.parse_args()

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    # ۱) بارگذاری داده خام؛ فایل‌های اصلی تغییر داده نمی‌شوند.
    G_raw = nx.read_graphml(args.graph)
    grid_raw = np.load(args.grid, allow_pickle=False)

    if not G_raw.is_directed():
        raise ValueError("گراف ورودی جهت‌دار نیست؛ انتظار می‌رود جهت خیابان‌ها حفظ شده باشد.")
    if not G_raw.is_multigraph():
        print("هشدار: گراف ورودی MultiDiGraph نیست؛ یال‌های موازی ممکن است در منبع ادغام شده باشند.")

    # ۲) آماده‌سازی جدول گره‌ها و تبدیل مختصات به عدد
    node_rows = []
    for node_id, attrs in G_raw.nodes(data=True):
        row = {"node_id": str(node_id)}
        row.update(attrs)
        node_rows.append(row)
    nodes = pd.DataFrame(node_rows)
    for col in ("x", "y", "street_count"):
        if col in nodes:
            nodes[col] = nodes[col].map(to_number)

    # ۳) آماده‌سازی یال‌ها با حفظ کلید یال‌های موازی
    edge_rows = []
    if G_raw.is_multigraph():
        iterator = G_raw.edges(keys=True, data=True)
        for u, v, key, attrs in iterator:
            row = {"u": str(u), "v": str(v), "edge_key": str(key)}
            row.update(attrs)
            edge_rows.append(row)
    else:
        for u, v, attrs in G_raw.edges(data=True):
            row = {"u": str(u), "v": str(v), "edge_key": "0"}
            row.update(attrs)
            edge_rows.append(row)
    edges = pd.DataFrame(edge_rows)
    if "length" not in edges:
        raise ValueError("ویژگی ضروری length در یال‌ها وجود ندارد.")
    edges["length"] = edges["length"].map(to_number)

    # ۴) کنترل کیفیت و تعیین رکوردهای معتبر
    # گزارش جامع مقادیر گمشده و نوع ویژگی‌ها برای هر دو جدول
    missing_rows = []
    for table_name, frame in (("nodes", nodes), ("edges", edges)):
        for column in frame.columns:
            missing_count = int(frame[column].isna().sum())
            missing_rows.append({
                "table": table_name,
                "feature": column,
                "data_type": str(frame[column].dtype),
                "missing_count": missing_count,
                "missing_percent": float(100 * missing_count / len(frame)) if len(frame) else 0.0,
                "unique_values": int(frame[column].nunique(dropna=True))
            })
    missing_details = pd.DataFrame(missing_rows)
    missing_details.to_csv(out/"missing_values_by_feature.csv", index=False, encoding="utf-8-sig")

    node_identity_duplicates = int(nodes["node_id"].duplicated().sum())
    edge_identity_duplicates = int(edges.duplicated(["u", "v", "edge_key"]).sum())
    missing_x = int(nodes["x"].isna().sum()) if "x" in nodes else len(nodes)
    missing_y = int(nodes["y"].isna().sum()) if "y" in nodes else len(nodes)
    invalid_coordinates = 0
    if {"x", "y"}.issubset(nodes.columns):
        invalid_coordinates = int((~nodes["x"].between(-180,180) | ~nodes["y"].between(-90,90)).fillna(True).sum())

    missing_length = int(edges["length"].isna().sum())
    nonpositive_length = int((edges["length"] <= 0).fillna(False).sum())
    missing_highway = int(edges["highway"].isna().sum()) if "highway" in edges else len(edges)
    unknown_endpoints = int((~edges["u"].isin(nodes["node_id"]) | ~edges["v"].isin(nodes["node_id"])).sum())

    # سیاست پاک‌سازی: رکوردهای خام حذف نمی‌شوند؛ فقط نسخه تحلیلی از یال‌های دارای
    # طول عددی مثبت و دو سر موجود ساخته می‌شود. ویژگی‌های اختیاری پر نمی‌شوند.
    valid_edge_mask = (
        edges["length"].notna() &
        (edges["length"] > 0) &
        edges["u"].isin(nodes["node_id"]) &
        edges["v"].isin(nodes["node_id"])
    )
    clean_edges = edges.loc[valid_edge_mask].copy()
    valid_nodes = nodes.loc[
        nodes["node_id"].isin(set(clean_edges["u"]) | set(clean_edges["v"]))
    ].copy()

    # ساخت گراف آماده تحلیل، با حفظ جهت و یال‌های موازی
    G_clean = nx.MultiDiGraph()
    for _, row in valid_nodes.iterrows():
        attrs = row.drop(labels=["node_id"]).dropna().to_dict()
        G_clean.add_node(row["node_id"], **attrs)
    for _, row in clean_edges.iterrows():
        attrs = row.drop(labels=["u","v","edge_key"]).dropna().to_dict()
        G_clean.add_edge(row["u"], row["v"], key=str(row["edge_key"]), **attrs)

    # ۵) ارزیابی گرید؛ طبق طراحی: ۱=سلول خیابان، ۰=غیرخیابان
    if grid_raw.ndim != 2:
        raise ValueError(f"گرید باید دوبعدی باشد؛ ndim={grid_raw.ndim}")
    if not np.isfinite(grid_raw).all():
        raise ValueError("گرید دارای NaN یا مقدار بی‌نهایت است.")
    unique_values = set(np.unique(grid_raw).tolist())
    if not unique_values.issubset({0,1,False,True}):
        raise ValueError(f"گرید دودویی نیست؛ مقادیر مشاهده‌شده: {unique_values}")
    road_mask = (grid_raw == 1)  # قرارداد طراحی پروژه
    nonroad_mask = (grid_raw == 0)
    grid_summary = {
        "grid_rows": int(grid_raw.shape[0]),
        "grid_cols": int(grid_raw.shape[1]),
        "grid_cells_total": int(grid_raw.size),
        "road_cells_1": int(road_mask.sum()),
        "nonroad_cells_0": int(nonroad_mask.sum()),
        "road_cell_percent": float(100 * road_mask.mean()),
        "grid_dtype": str(grid_raw.dtype),
        "grid_binary": True,
        "grid_contract": "1=road/traversable, 0=non-road"
    }

    # ۶) آزمون‌های ساختاری و اتصال‌پذیری
    weak_components = list(nx.weakly_connected_components(G_clean))
    strong_components = list(nx.strongly_connected_components(G_clean))
    largest_weak = max((len(c) for c in weak_components), default=0)
    largest_strong_nodes = max(strong_components, key=len) if strong_components else set()
    largest_strong = len(largest_strong_nodes)

    # ۷) ارزیابی مسیر: جفت‌ها فقط از بزرگ‌ترین مؤلفه قویاً همبند انتخاب می‌شوند
    # تا برای هر جفت، وجود مسیر جهت‌دار انتظارپذیر باشد.
    route_rows = []
    if len(largest_strong_nodes) >= 2 and args.pairs > 0:
        rng = random.Random(2026)
        candidates = sorted(largest_strong_nodes)
        pair_count = min(args.pairs, max(1, len(candidates)//2))
        for i in range(pair_count):
            source, target = rng.sample(candidates, 2)
            try:
                route = nx.shortest_path(G_clean, source, target, weight="length", method="dijkstra")
                route_length = nx.path_weight(G_clean, route, weight="length")
                route_rows.append({
                    "test_id": i+1, "origin": source, "destination": target,
                    "route_found": True, "node_count": len(route),
                    "edge_count": len(route)-1, "route_length_m": float(route_length),
                    "status": "success"
                })
            except (nx.NetworkXNoPath, nx.NodeNotFound):
                route_rows.append({
                    "test_id": i+1, "origin": source, "destination": target,
                    "route_found": False, "node_count": 0, "edge_count": 0,
                    "route_length_m": np.nan, "status": "no_path"
                })

    routes = pd.DataFrame(route_rows)
    success_count = int(routes["route_found"].sum()) if not routes.empty else 0

    # ۸) ذخیره خروجی‌ها و گزارش خلاصه
    quality = {
        "raw_graph_type": type(G_raw).__name__,
        "directed": bool(G_raw.is_directed()),
        "multigraph": bool(G_raw.is_multigraph()),
        "raw_nodes": int(G_raw.number_of_nodes()),
        "raw_edges": int(G_raw.number_of_edges()),
        "node_id_duplicates": node_identity_duplicates,
        "edge_identity_duplicates": edge_identity_duplicates,
        "missing_node_x": missing_x,
        "missing_node_y": missing_y,
        "invalid_node_coordinates": invalid_coordinates,
        "missing_edge_length": missing_length,
        "nonpositive_edge_length": nonpositive_length,
        "missing_highway": missing_highway,
        "edges_with_unknown_endpoint": unknown_endpoints,
        "clean_nodes": int(G_clean.number_of_nodes()),
        "clean_edges": int(G_clean.number_of_edges()),
        "removed_from_analysis_edges": int(len(edges)-len(clean_edges)),
        "weakly_connected_components": len(weak_components),
        "largest_weak_component_nodes": largest_weak,
        "strongly_connected_components": len(strong_components),
        "largest_strong_component_nodes": largest_strong,
        "route_tests": int(len(routes)),
        "successful_routes": success_count,
        "route_success_rate_percent": float(100*success_count/len(routes)) if len(routes) else None,
        **grid_summary
    }
    pd.DataFrame([quality]).to_csv(out/"data_quality_summary.csv", index=False, encoding="utf-8-sig")
    nodes.to_csv(out/"nodes_prepared.csv", index=False, encoding="utf-8-sig")
    clean_edges.to_csv(out/"edges_clean.csv", index=False, encoding="utf-8-sig")
    routes.to_csv(out/"route_evaluation.csv", index=False, encoding="utf-8-sig")
    (out/"quality_report.json").write_text(json.dumps(quality, ensure_ascii=False, indent=2), encoding="utf-8")

    # گزارش متنی با توضیح سیاست‌های پاک‌سازی
    report = f"""# گزارش پاک‌سازی و ارزیابی داده‌های مسیریابی شیراز

## خلاصه
- نوع گراف خام: {quality['raw_graph_type']}؛ جهت‌دار: {quality['directed']}؛ چندگرافی: {quality['multigraph']}
- گره‌ها: {quality['raw_nodes']:,}؛ یال‌ها: {quality['raw_edges']:,}
- گره‌های نسخه تحلیلی: {quality['clean_nodes']:,}؛ یال‌های نسخه تحلیلی: {quality['clean_edges']:,}
- یال‌های کنارگذاشته‌شده از نسخه تحلیلی به علت طول نامعتبر/غیرمثبت یا سرناموجود: {quality['removed_from_analysis_edges']:,}
- مؤلفه‌های قویاً همبند: {quality['strongly_connected_components']:,}
- بزرگ‌ترین مؤلفه قویاً همبند: {quality['largest_strong_component_nodes']:,} گره
- آزمون مسیر: {quality['route_tests']}؛ مسیرهای موفق: {quality['successful_routes']}

## سیاست پاک‌سازی
1. فایل‌های خام بدون تغییر نگه داشته شدند.
2. مختصات گره‌ها و طول یال‌ها به نوع عددی تبدیل شدند؛ مقدار نامعتبر به‌صورت گمشده علامت‌گذاری شد.
3. برای نسخه تحلیلی، یال فاقد طول عددی مثبت یا دارای گره مبدأ/مقصد ناموجود کنار گذاشته شد.
4. ویژگی‌های اختیاری مانند نام خیابان، عرض، پل، تونل و سرعت با مقدار ساختگی پر نشدند.
5. جهت‌داری گراف و کلید یال‌های موازی حفظ شد.

## قرارداد گرید
گرید دوبعدی مطابق مستند طراحی تفسیر شده است: مقدار ۱ سلول خیابان/قابل عبور و مقدار ۰ سایر سلول‌ها است. برای الگوریتم‌هایی که قرارداد معکوس دارند باید ماسک عبورپذیری جداگانه ساخته شود؛ فایل اصلی گرید تغییر داده نشده است.

## محدودیت ارزیابی
مسیرها با وزن طول یال و الگوریتم دایکسترا ارزیابی شده‌اند. این آزمون صحت ساختاری و امکان یافتن مسیر را می‌سنجد، نه زمان واقعی سفر یا ترافیک. برای مقایسه الگوریتم‌های مختلف، باید مجموعه جفت‌های مبدأ-مقصد ثابت و یکسان استفاده شود.
"""
    (out/"data_preparation_evaluation_report.md").write_text(report, encoding="utf-8")
    print(json.dumps(quality, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
